package com.lims.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.lims.bean.BooksInventory;
import com.lims.bean.BooksRegistration;
import com.lims.bean.Users;

public interface ILIMSService {

	

	boolean login(String userName, String password, Users user1);

	ArrayList<BooksInventory> view(BooksInventory inventory);

	int addBook(BooksInventory inventory);

	int deleteBook(int deleteBookId);

	BooksInventory updateSearchBook(int booksearchId);

	int updateBook(BooksInventory inventory);

	String register(Users usr);

	boolean loginUser(String userName, String password, Users user1);

	int placeRequest(BooksRegistration registration) ;

	ArrayList<BooksRegistration> viewRequest(BooksRegistration registration);

	String issue(int id);

}
