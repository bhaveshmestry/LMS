package com.lims.bean;
import javax.persistence.*;


@Entity
@Table(name="BOOKSINVENTORY")
@NamedQuery(name = "viewalladmin", query = "select s from BooksInventory s")
public class BooksInventory {
	
	@Id
	@GeneratedValue
	@Column(name="book_id")
	private int bookId;
	@Column(name="book_name")
	private String bookName;
	@Column(name="author1")
	private String author1;
	@Column(name="author2")
	private String author2;
	@Column(name="publisher")
	private String publisher;
	@Column(name="yearofpublication")
	private String yearOfPublication;
	@Column(name="quantity")
	private int quantity;
	public BooksInventory() {
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getBookId() {
		return bookId;
	}
	
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	
	public String getBookName() {
		return bookName;
	}
	
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	public String getAuthor1() {
		return author1;
	}
	
	public void setAuthor1(String author1) {
		this.author1 = author1;
	}
	
	public String getAuthor2() {
		return author2;
	}
	
	public void setAuthor2(String author2) {
		this.author2 = author2;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	public String getYearOfPublication() {
		return yearOfPublication;
	}
	
	public void setYearOfPublication(String yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}
	
	
	
}
