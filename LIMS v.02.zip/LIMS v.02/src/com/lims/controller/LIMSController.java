package com.lims.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lims.bean.BooksInventory;
import com.lims.bean.BooksRegistration;
import com.lims.bean.BooksTransactions;
import com.lims.bean.Users;
import com.lims.service.ILIMSService;
//makes class as component class
@Controller
public class LIMSController {

	@Autowired
	ILIMSService service;

	/***********************************************************
	                    Displays Home Page
	 ***********************************************************/


	
	@RequestMapping("home")
	public String home(){

		return "home";
	}


	/***********************************************************
                       Displays About Us Page     
	 ***********************************************************/

	@RequestMapping("aboutus")
	public String aboutus(){

		return "aboutus";
	}
	
	/***********************************************************
              Displays Contact Us Page     
    ***********************************************************/
	@RequestMapping("contactus")
	public String contactus(){

		return "contactus";
	}

	/***********************************************************
                       Displays Index Page      
	 ***********************************************************/

	@RequestMapping("index")
	public String index(Model m,@ModelAttribute("contentObj") Users usr1){
		m.addAttribute(usr1);
		return "index";
	}


	/***********************************************************
                       Displays Login Page       
	 ***********************************************************/

	@RequestMapping("login") 
	public String loginUser(Model m,@ModelAttribute("contentObj") Users usr){
		m.addAttribute(usr);
		return "loginuser";
	}


	/***********************************************************
                       Displays Register Page      
	 ***********************************************************/

	@RequestMapping("register") 
	public String loginredirect(Model m,@ModelAttribute("contentObj") Users usr){
		m.addAttribute(usr);
		return "register";
	}


	/***********************************************************
                       Validates Register of User       
	 ***********************************************************/

	@RequestMapping("service") 
	public String service(Model m,@ModelAttribute("contentObj") Users usr,@RequestParam("confirm") String confirm,	HttpSession session){
		m.addAttribute(usr);
		String pass = usr.getPassword();
		String target = null;
		if(pass.equals(confirm))
		{
			String msg = service.register(usr);
			m.addAttribute("msg",usr.getUserID());
			int id=usr.getUserID();
			session.setAttribute("id",id);
			target = "loginuser";
		}
		else
		{
			m.addAttribute("msg","Passwords don't match");
			target = "register";
		}
		
		return target;
	}


	/***********************************************************
                      Validates Login for User     
	 ***********************************************************/

	@RequestMapping("loginuser")
	public String goToService(Model m, @ModelAttribute("contentObj") Users user1,HttpSession session){
		String target = null;
		m.addAttribute(user1);
		m.addAttribute("usr",user1.getUserName());
		m.addAttribute("pass",user1.getPassword());
		user1 = service.loginUser(user1.getUserName(), user1.getPassword() , user1);
		if(user1.getUserID()!=0)
		{
			m.addAttribute("registrationObj",new BooksRegistration());
			session.setAttribute("userId",user1.getUserID());
			target = "contentuser";

		}
		else
		{
			target = "loginuser";
			m.addAttribute("status","Login Unsuccessful");
			m.addAttribute("contentObj",user1);

		}
		return target;
	}

	/***********************************************************
                    Displays Login Page for Admin    
	 ***********************************************************/
	@RequestMapping("loginadmin")
	public String login(Model m,@ModelAttribute("contentObj") Users user){
		
		m.addAttribute("contentObj",user);
		return "loginadmin";
	}


	/***********************************************************
                       Validates Login for Admin     
	 ***********************************************************/

	@RequestMapping("content")
	public String gotoservice(Model m, @ModelAttribute("contentObj") Users user1,HttpSession session){
		String target = null;
		m.addAttribute(user1);
		m.addAttribute("user",user1.getUserName());
		m.addAttribute("pass",user1.getPassword());
		user1 = service.login(user1.getUserName(), user1.getPassword() , user1);
		if(user1.getUserID()!=0)
		{
			
			m.addAttribute("contentObj" , user1);
			session.getAttribute("userId");
			target = "contentadmin";
		}
		else
		{
			target = "loginadmin";
			m.addAttribute("status","Login Unsuccessful");

		}
		return target;
	}


	/***********************************************************
                      Displays content Page for Admin    
	 ***********************************************************/
	@RequestMapping("contentadmin")
	public String backToContent(Model m,@ModelAttribute("contentObj") Users user){

		m.addAttribute("contentObj",user);
		return "contentadmin";
	}
	/***********************************************************
                Displays content Page for User    
    ***********************************************************/
	@RequestMapping("/contentuser")
	public String backToContentOfUser(Model m,@ModelAttribute("contentObj") Users user,HttpSession session){

		m.addAttribute("contentObj",user);
		session.getAttribute("userId");
		return "contentuser";
	}

	/***********************************************************
                    Displays Place Request Page for User    
	 ***********************************************************/
	@RequestMapping("placerequest")
	public String placeRequest(Model m,HttpSession session){
		session.getAttribute("userId");
		m.addAttribute("registrationObj",new BooksRegistration());
		return "placerequest";
	}


	/***********************************************************
                    Validates Request for User   
	 ***********************************************************/
	@RequestMapping("successplacerequest")
	public String successPlaceRequest(Model m,@ModelAttribute("registrationObj") BooksRegistration registration,HttpSession session){
		String target=null;
		System.out.println("Session "+session.getAttribute("userId"));
		int id1 = (int) session.getAttribute("userId");
		System.out.println(id1);
		registration.setUserID(id1);
		int id=service.placeRequest(registration);
		if(id>0)
		{
			System.out.println("in if");
			m.addAttribute("msg","Book request is placed with id:");
			session.getAttribute("userId");
			m.addAttribute("id",registration.getUserID());
			target="successplacerequest";
		}
		else
		{
			target="contentuser";
		}
		return target;
	}


	/***********************************************************
               Displays View All Books Page for Admin
	 ***********************************************************/
	@RequestMapping("viewallbooksadmin")
	public String getAllBooksAdmin(Model m,BooksInventory inventory)
	{
		ArrayList<BooksInventory> list = service.view(inventory);
		m.addAttribute("list",list);
		return "viewallbooksadmin";
	}
	

	/***********************************************************
               Displays View All Books Page for User
	 ***********************************************************/
	@RequestMapping("viewallbooksuser")
	public String getAllBooksUser(Model m,BooksInventory inventory)
	{
		ArrayList<BooksInventory> list = service.view(inventory);
		m.addAttribute("list",list);
		return "viewallbooksuser";
	}


	/***********************************************************
                 Displays Add Books Page for Admin
	 ***********************************************************/
	@RequestMapping("addbook")
	public String getAdd(Model m)
	{
		m.addAttribute("bookinventoryObj",new BooksInventory());
		return "addbook";
	}


	/***********************************************************
                 Allows Admin to Add books into book list
	 ***********************************************************/
	@RequestMapping(value="successadd",method=RequestMethod.POST)
	public String addBook(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int id=service.addBook(inventory);
		if(id>0)
		{
			System.out.println("in if");
			m.addAttribute("msg","Book stored to Booklist with id:");
			m.addAttribute("id",id);
			target="successadd";
		}
		else
		{
			target="contentadmin";
		}
		return target;

	}


	/***********************************************************
              Allows Admin to Search book by Id for Updating
	 ***********************************************************/
	@RequestMapping("updatesearch")
	public String getUpdate(Model m)
	{
		m.addAttribute("bookinventoryObj",new BooksInventory());
		return "updatesearch";
	}


	/***********************************************************
            Directs to Update Book Page for Admin
	 ***********************************************************/
	@RequestMapping(value="update",method=RequestMethod.POST)
	public String updateScheduleDetailsPage(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int booksearchId=inventory.getBookId();
		BooksInventory result=service.updateSearchBook(booksearchId);
		if(result==null)
		{
			target="updatesearch";
			m.addAttribute("msg","No such book Available");
		}
		else
		{
			m.addAttribute("updatelist",result);
			System.out.println("In controller");
			target="updatebook";	
		}
		return target;
	} 


	/***********************************************************
           Allows Admin to Update books into existing table 
	 ***********************************************************/
	@RequestMapping(value="successupdate",method=RequestMethod.POST)
	public String updateBook(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int id=service.updateBook(inventory);
		if(id>0)
		{
			System.out.println("in if");
			m.addAttribute("msg","Book details updated Successfully");
			target="successupdate";
		}
		else
		{
			target="contentadmin";
		}
		return target;
	}



	/***********************************************************
                 Displays Delete Books Page for Admin
	 ***********************************************************/
	@RequestMapping("delete")
	public String getDelete(Model m)
	{
		BooksInventory books = new BooksInventory();
		
		ArrayList<BooksInventory> idList = service.getBookID(books);
		System.out.println("Id List is : "+idList);
		m.addAttribute("bookinventoryObj",books);
		m.addAttribute("id",idList);
		return "deletebook";
	}


	/***********************************************************
                Allows Admin to Delete books into book list
	 ***********************************************************/
	@RequestMapping(value="successdelete",method=RequestMethod.POST)
	public String deleteBook(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int deleteBookId=inventory.getBookId();
		int result;
		result=service.deleteBook(inventory);
		System.out.println("Id : "+result);
		if(result>0)
		{
			System.out.println("in if");
			m.addAttribute("msg","Book details deleted Successfully");
			target="successdelete";
		}
		else
		{
			target="deletebook";
			m.addAttribute("msg","Cannot find such book to delete");
		}
		return target;
	}
	/***********************************************************
             View requests of users for book to Admin
    ***********************************************************/
	@RequestMapping("viewrequest")
	public String getAllRequest(Model m,BooksRegistration registration)
	{
		ArrayList<BooksRegistration> list = service.viewRequest(registration);
		m.addAttribute("list",list);
		return "viewrequest";
	}
	
	
	@RequestMapping("logout")
	public String logout(){
      
		return "home";
	}
	
	@RequestMapping("issue")
	public String Issue(Model m,@RequestParam("id") int id){
		
		System.out.println(id);
		String msg = service.issue(id);
		m.addAttribute("obj",new BooksRegistration());
		m.addAttribute("id",msg);
		return "issue";
	}
	
	@RequestMapping("reject")
	public String Reject(Model m,@RequestParam("id") int id){
		
		System.out.println(id);
		String msg  = service.reject(id);
		m.addAttribute("obj",new BooksRegistration());
		m.addAttribute("id",id);
		return "reject";
	}
	
	
	@RequestMapping("return")
	public String returnBook(Model m,BooksTransactions trans){
      
		ArrayList<BooksTransactions> list = service.getTransList(trans);
		m.addAttribute("list",list);
		System.out.println(list);
;		return "viewMyRequest";
	}
	
	
}
