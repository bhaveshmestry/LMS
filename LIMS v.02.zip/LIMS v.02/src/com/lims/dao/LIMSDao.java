package com.lims.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lims.bean.BooksInventory;
import com.lims.bean.BooksRegistration;
import com.lims.bean.BooksTransactions;
import com.lims.bean.Users;

@Repository
@Transactional
public class LIMSDao implements ILIMSDao{

	@PersistenceContext 
	EntityManager entitymanager;

	@Override
	public Users login(String userName, String password, Users user1) {
		Query qry = entitymanager.createNamedQuery("loginqryadmin");
		qry.setParameter("user",user1.getUserName());
		qry.setParameter("pass",user1.getPassword());
		try
		{
		user1=(Users) qry.getSingleResult();
		System.out.println(user1);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return user1;
	}

	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		Query qry = entitymanager.createNamedQuery("viewalladmin");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		return list;
	}

	@Override
	public int addBook(BooksInventory inventory) {
		
		Query qry = entitymanager.createQuery("select bk from BooksInventory bk");
		ArrayList<BooksInventory> inventList = (ArrayList<BooksInventory>) qry.getResultList();
		System.out.println(inventList);
		for(BooksInventory inventory2 : inventList)
		{
		if(inventory2.getBookName().equals(inventory.getBookName()))
		{
			System.out.println("-----------------------Normal Name"+inventory.getBookName());
			System.out.println("------------------------List Name"+inventory2.getBookName());
			int qty = inventory2.getQuantity();
			System.out.println("--------------------------------------------------------------------------Quantity : "+qty);
			String bkname = inventory2.getBookName();
			Query qry2 = entitymanager.createQuery("update BooksInventory book set book.quantity=:qty1 where book.bookName=:bkname");
			int qty1 = 0;
			 qty1 = qty+1;
			qry2.setParameter("qty1",qty1);
			System.out.println("Increement value of quantity :"+qty1);
			qry2.setParameter("bkname",bkname);
			System.out.println("                               Working                              ");
			qry2.executeUpdate();
			System.out.println(inventory2.getQuantity());
			return inventory2.getBookId();
		}
		}
		inventory.setQuantity(1);
		entitymanager.persist(inventory);
		return inventory.getBookId();
	}

	@Override
	public int deleteBook(BooksInventory inventory) {
		Query deleteQuery=entitymanager.createQuery("delete BooksInventory b where b.bookId =:delbookid and b.quantity=1");
		deleteQuery.setParameter("delbookid",inventory.getBookId());
		int result = deleteQuery.executeUpdate();
		String msg = null;
		if(result>0)
		{
			System.out.println("Delete Done : ");
		}
		else
		{
			Query qry = entitymanager.createQuery("select bk from BooksInventory bk where bk.bookId=:bookID");
			qry.setParameter("bookID", inventory.getBookId());
			BooksInventory inventobj = (BooksInventory) qry.getSingleResult();
			System.out.println(inventobj);
			if(inventobj!=null)
			{
				System.out.println("-----------------------Normal Name"+inventory.getBookName());
				System.out.println("------------------------List Name"+inventobj.getBookName());
				int qty = inventobj.getQuantity();
				System.out.println("--------------------------------------------------------------------------Quantity : "+qty);
				String bkname = inventobj.getBookName();
				Query qry2 = entitymanager.createQuery("update BooksInventory book set book.quantity=:qty1 where book.bookName=:bkname");
				int qty1 = 0;
				 qty1 = qty-1;
				qry2.setParameter("qty1",qty1);
				System.out.println("Decreement value of quantity :"+qty1);
				qry2.setParameter("bkname",bkname);
				System.out.println("                               Working                              ");
				qry2.executeUpdate();
				System.out.println(inventobj.getQuantity());
				result =  inventobj.getBookId();
			}
			else
			{
				return 0;
			}
		}
		
		return result;
		}
		

	@Override
	public BooksInventory updateSearchBook(int booksearchId) {
		try{
		Query updateQuery=entitymanager.createQuery("select book from BooksInventory book where bookId =:upbookid");
		updateQuery.setParameter("upbookid", booksearchId);
		BooksInventory result = (BooksInventory) updateQuery.getSingleResult();
		return result;
		}
		catch(Exception e)
		{
			return null;
		}
		
	}
	@Override
	public int updateBook(BooksInventory inventory) {
		entitymanager.merge(inventory);
		return inventory. getBookId();
	}

	@Override
	public String register(Users usr) {
		System.out.println(entitymanager);
		entitymanager.persist(usr);
		
		
		return "Registered Successfully";
	}

	@Override
	public Users loginUser(String userName, String password, Users user1) {
		Query qry = entitymanager.createNamedQuery("userLoginQry");
		qry.setParameter("user",user1.getUserName());
		qry.setParameter("pass",user1.getPassword());
		try
		{
		user1=(Users) qry.getSingleResult();
		System.out.println(user1);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return user1;
	}

	@Override
	public int placeRequest(BooksRegistration registration){
		
		try
		{
		registration.setRegistrationDate(new Date());
		registration.setStatus(false);
		entitymanager.persist(registration);
		return registration. getRegistrationId();
		}
		catch(Exception e)
		{
			return 0;
		}
	
	
		
	}

	@Override
	public ArrayList<BooksRegistration> viewRequest(BooksRegistration registration) {
		Query qry = entitymanager.createNamedQuery("viewallrequest");
		ArrayList<BooksRegistration> list = (ArrayList<BooksRegistration>) qry.getResultList();
		return list;
	}

	@Override
	public String issue(int id) {
		BooksTransactions trans = new BooksTransactions();
		trans.setIssueDate(new Date());
		Calendar cal = Calendar.getInstance();
		Date date = trans.getIssueDate();
		 cal.setTime(date);
		 cal.add(Calendar.DAY_OF_MONTH, 14);  
		 Date adddate = cal.getTime();

		 trans.setFine(0);
		 System.out.println(trans.getFine());
		 trans.setIssueDate(date);
		 System.out.println(trans.getIssueDate());
		 trans.setReturnDate(adddate);
		 System.out.println(trans.getReturnDate());
		 trans.setRegistrationId(id);
		 System.out.println(trans.getRegistrationId());
		 
		 Query qry = entitymanager.createQuery("update BooksRegistration r  SET  r.status=1  where r.bookId  IN  (select  bk.bookId  from  BooksInventory  bk  where  bk.quantity=1) and  r.registrationId=:id1)");
		qry.setParameter("id1", id);
		System.out.println(id);
		int result= qry.executeUpdate();
		System.out.println("Working:   "+result);
		if(result>0)
		{
			System.out.println("Update Done : ");
		}
		else
		{
			Query qry1 = entitymanager.createQuery("select bk from BooksInventory bk where bk.bookId IN (select bk.bookId from BooksRegistration bk where bk.registrationId=:regId)");
			qry1.setParameter("regId", id);
			BooksInventory inventobj = (BooksInventory) qry.getSingleResult();
			System.out.println(inventobj);
			if(inventobj!=null)
			{
				System.out.println("------------------------List Name"+inventobj.getBookName());
				int qty = inventobj.getQuantity();
				System.out.println("--------------------------------------------------------------------------Quantity : "+qty);
				String bkname = inventobj.getBookName();
				Query qry2 = entitymanager.createQuery("update BooksInventory book set book.quantity=:qty1 where book.bookName=:bkname");
				int qty1 = 0;
				 qty1 = qty-1;
				qry2.setParameter("qty1",qty1);
				System.out.println("Decreement value of quantity :"+qty1);
				qry2.setParameter("bkname",bkname);
				System.out.println("                               Working                              ");
				qry2.executeUpdate();
				System.out.println(inventobj.getQuantity());
				result =  inventobj.getBookId();
			}
			else
			{
				result = 0;
			}
		}
		String msg = "Success";
		if(result>=1)
		{
			 entitymanager.persist(trans);
		}
		else
		{
			msg="Error";
		}
		 
		//Query qry = entitymanager.createQuery("insert into BooksTransactions book (book.registrationId,book.issueDate,book.returnDate,book.fine) values (id1,date1,addDate1,fine)");
	
		return msg;
	}

	@Override
	public String reject(int id) {
		String msg = null;
		Query qry = entitymanager.createQuery("delete BooksRegistration register where register.registrationId=:id1");
		qry.setParameter("id1", id);
		int result = qry.executeUpdate();
		if(result>=1)
		{
			msg = "Success";
		}
		else
		{
			msg = "Unsuccess";
		}
		return msg;
	}

	@Override
	public ArrayList<BooksTransactions> getTransList(BooksTransactions trans) {
		
		Query qry = entitymanager.createQuery("select s from BooksTransactions s");
		ArrayList<BooksTransactions> list = (ArrayList<BooksTransactions>) qry.getResultList();
		
		System.out.println(trans.getTransactionId());
		return list;
	}

	@Override
	public ArrayList<BooksInventory> getBookId(BooksInventory books) {
		
		Query qry = entitymanager.createQuery("select distinct book.bookId from BooksInventory book where book.quantity >= '1' and book.bookId <> all(select b.bookId from BooksRegistration b where b.status=1)");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		System.out.println("List : "+list);
		return list;
	}


}
