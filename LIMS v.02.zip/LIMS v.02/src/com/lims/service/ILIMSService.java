package com.lims.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.lims.bean.BooksInventory;
import com.lims.bean.BooksRegistration;
import com.lims.bean.BooksTransactions;
import com.lims.bean.Users;

public interface ILIMSService {

	

	Users login(String userName, String password, Users user1);

	ArrayList<BooksInventory> view(BooksInventory inventory);

	int addBook(BooksInventory inventory);

	int deleteBook(BooksInventory inventory);

	BooksInventory updateSearchBook(int booksearchId);

	int updateBook(BooksInventory inventory);

	String register(Users usr);

	Users loginUser(String userName, String password, Users user1);

	int placeRequest(BooksRegistration registration) ;

	ArrayList<BooksRegistration> viewRequest(BooksRegistration registration);

	String issue(int id);

	String reject(int id);

	ArrayList<BooksTransactions> getTransList(BooksTransactions trans);

	ArrayList<BooksInventory> getBookID(BooksInventory books);

}
