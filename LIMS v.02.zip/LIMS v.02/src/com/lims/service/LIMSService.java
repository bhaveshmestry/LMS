package com.lims.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lims.bean.BooksInventory;
import com.lims.bean.BooksRegistration;
import com.lims.bean.BooksTransactions;
import com.lims.bean.Users;
import com.lims.dao.ILIMSDao;

@Service
public class LIMSService implements ILIMSService{
	@Autowired
    ILIMSDao dao;
	@Override
	public boolean login(String userName, String password, Users user1) {
		return dao.login(user1.getUserName(), user1.getPassword() , user1);
	}
	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		return  dao.view(inventory);
	}
	@Override
	public int addBook(BooksInventory inventory) {
		int id=dao.addBook(inventory);
		return id;
	}
	@Override
	public int deleteBook(int deleteBookId) {
		int result=dao.deleteBook(deleteBookId);
		return result;
	}
	@Override
	public BooksInventory updateSearchBook(int booksearchId) {
		BooksInventory result=dao.updateSearchBook(booksearchId);
		return result;
	}
	@Override
	public int updateBook(BooksInventory inventory) {
		int id=dao.updateBook(inventory);
		return id;
	}
	@Override
	public String register(Users usr) {
		return dao.register(usr);
	}
	@Override
	public boolean loginUser(String userName, String password, Users user1) {
		return dao.loginUser(user1.getUserName(), user1.getPassword() , user1);
	}
	@Override
	public int placeRequest(BooksRegistration registration) {
	 int id=dao.placeRequest(registration);
	 return id;
	}
	@Override
	public ArrayList<BooksRegistration> viewRequest(BooksRegistration registration) {
		return dao.viewRequest(registration);
	}
	@Override
	public String issue(int id) {
		
		return dao.issue(id);
	}
	@Override
	public String reject(int id) {
		
		return dao.reject(id);
	}
	@Override
	public ArrayList<BooksTransactions> getTransList(BooksTransactions trans) {
		ArrayList<BooksTransactions> list = dao.getTransList(trans);
		for(BooksTransactions trans1 : list)
		{
			System.out.println(trans1.getReturnDate());
			Date today = new Date();
			Date returnDate = trans1.getReturnDate();
			if(returnDate.before(today))
			{
			int fine = (int) Math.abs((returnDate.getTime() - today.getTime())*5/ (1000 * 60 * 60 * 24));	
			System.out.println(fine);
			trans1.setFine(fine);
			}
		}
		return list;
	}
	
}
