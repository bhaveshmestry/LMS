package com.lims.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.lims.bean.BooksInventory;
import com.lims.bean.BooksRegistration;
import com.lims.bean.BooksTransactions;
import com.lims.bean.Users;

public interface ILIMSDao {

	boolean login(String userName, String password, Users user1);

	ArrayList<BooksInventory> view(BooksInventory inventory);

	int addBook(BooksInventory inventory);

	int updateBook(BooksInventory inventory);

	int deleteBook(int deleteBookId);

	BooksInventory updateSearchBook(int booksearchId);

	String register(Users usr);

	boolean loginUser(String userName, String password, Users user1);

	int placeRequest(BooksRegistration registration) ;

	ArrayList<BooksRegistration> viewRequest(BooksRegistration registration);

	String issue(int id);

	String reject(int id);

	ArrayList<BooksTransactions> getTransList(BooksTransactions trans);

	ArrayList<BooksRegistration> getBookId(BooksRegistration books);

}
