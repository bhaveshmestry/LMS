package com.lims.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lims.bean.BooksInventory;
import com.lims.bean.BooksRegistration;
import com.lims.bean.BooksTransactions;
import com.lims.bean.Users;

@Repository
@Transactional
public class LIMSDao implements ILIMSDao{

	@PersistenceContext 
	EntityManager entitymanager;

	@Override
	public boolean login(String userName, String password, Users user1) {
		boolean status = true;
		Query qry = entitymanager.createNamedQuery("loginqryadmin");
		qry.setParameter("user",user1.getUserName());
		qry.setParameter("pass",user1.getPassword());
		List result =qry.getResultList();
		System.out.println(result);
		if(result.isEmpty())
		{
			status = false;
		}
		return status;
	}

	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		Query qry = entitymanager.createNamedQuery("viewalladmin");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		return list;
	}

	@Override
	public int addBook(BooksInventory inventory) {
		Query qry = entitymanager.createQuery("select bk from BooksInventory bk");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		for(BooksInventory inventory1:list)
		{
			System.out.println("bookname : --------"+inventory1.getBookName());
			System.out.println("bookname : --------"+inventory.getBookName());
			if(inventory1.getBookName().equals(inventory.getBookName()))
					{
						int count = inventory1.getQuantity();
						System.out.println("Count : --------"+count);
						count++;
						System.out.println("Count : --------"+count);
						return inventory1.getBookId();
					}
		}
		entitymanager.persist(inventory);
		return inventory.getBookId();
	}

	@Override
	public int deleteBook(int deleteBookId) {
		Query deleteQuery=entitymanager.createQuery("delete BooksInventory where bookId =:delbookid");
		deleteQuery.setParameter("delbookid",deleteBookId);
		int result = deleteQuery.executeUpdate();
		return result;
	}

	@Override
	public BooksInventory updateSearchBook(int booksearchId) {
		try{
		Query updateQuery=entitymanager.createQuery("select book from BooksInventory book where bookId =:upbookid");
		updateQuery.setParameter("upbookid", booksearchId);
		BooksInventory result = (BooksInventory) updateQuery.getSingleResult();
		return result;
		}
		catch(Exception e)
		{
			return null;
		}
		
	}
	@Override
	public int updateBook(BooksInventory inventory) {
		entitymanager.merge(inventory);
		return inventory. getBookId();
	}

	@Override
	public String register(Users usr) {
		System.out.println(entitymanager);
		entitymanager.persist(usr);
		
		
		return "Registered Successfully";
	}

	@Override
	public boolean loginUser(String userName, String password, Users user1) {
		boolean status = true;
		HttpSession session = null;
		Query qry = entitymanager.createNamedQuery("userLoginQry");
		qry.setParameter("user",user1.getUserName());
		qry.setParameter("pass",user1.getPassword());
		
		List<Users> result =qry.getResultList();
		System.out.println(result);
		if(result.isEmpty())
		{
			status = false;
		}
		return status;
	}

	@Override
	public int placeRequest(BooksRegistration registration){
		
		try
		{
		registration.setRegistrationDate(new Date());
		registration.setStatus(false);
		entitymanager.persist(registration);
		return registration. getRegistrationId();
		}
		catch(Exception e)
		{
			return 0;
		}
	
	
		
	}

	@Override
	public ArrayList<BooksRegistration> viewRequest(BooksRegistration registration) {
		Query qry = entitymanager.createNamedQuery("viewallrequest");
		ArrayList<BooksRegistration> list = (ArrayList<BooksRegistration>) qry.getResultList();
		return list;
	}

	@Override
	public String issue(int id) {
		BooksTransactions trans = new BooksTransactions();
		trans.setIssueDate(new Date());
		Calendar cal = Calendar.getInstance();
		Date date = trans.getIssueDate();
		 cal.setTime(date);
		 cal.add(Calendar.DAY_OF_MONTH, 14);  
		 Date adddate = cal.getTime();

		 trans.setFine(0);
		 System.out.println(trans.getFine());
		 trans.setIssueDate(date);
		 System.out.println(trans.getIssueDate());
		 trans.setReturnDate(adddate);
		 System.out.println(trans.getReturnDate());
		 trans.setRegistrationId(id);
		 System.out.println(trans.getRegistrationId());
		 
		 Query qry = entitymanager.createQuery("update BooksRegistration r set r.status=1 where r.registrationId=:id1");
		qry.setParameter("id1", id);
		int result = qry.executeUpdate();

		String msg = "Success";
		if(result>=1)
		{
			 entitymanager.persist(trans);
		}
		else
		{
			msg="Error";
		}
		 
		//Query qry = entitymanager.createQuery("insert into BooksTransactions book (book.registrationId,book.issueDate,book.returnDate,book.fine) values (id1,date1,addDate1,fine)");
	
		return msg;
	}

	@Override
	public String reject(int id) {
		String msg = null;
		Query qry = entitymanager.createQuery("delete BooksRegistration register where register.registrationId=:id1");
		qry.setParameter("id1", id);
		int result = qry.executeUpdate();
		if(result>=1)
		{
			msg = "Success";
		}
		else
		{
			msg = "Unsuccess";
		}
		return msg;
	}

	@Override
	public ArrayList<BooksTransactions> getTransList(BooksTransactions trans) {
		
		Query qry = entitymanager.createQuery("select s from BooksTransactions s");
		ArrayList<BooksTransactions> list = (ArrayList<BooksTransactions>) qry.getResultList();
		
		System.out.println(trans.getTransactionId());
		return list;
	}

	@Override
	public ArrayList<BooksRegistration> getBookId(BooksRegistration books) {
		
		Query qry = entitymanager.createQuery("select distinct book.bookId from BooksRegistration book where book.status=0");
		ArrayList<BooksRegistration> list = (ArrayList<BooksRegistration>) qry.getResultList();
		System.out.println("List : "+list);
		return list;
	}


}
