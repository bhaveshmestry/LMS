package com.library.dbutil;

public interface IQueryMapper {

	String login = "Select * from users where user_name = ? and password = ?";
	String view = "Select * from BooksInventory";
	String checkavail = "Select book_name from BooksInventory";
	String insert = "insert into book_transaction (transaction_id,return_date) values (BK_SEQ.NEXTVAL,SYSDATE+14)";
	String select = "select distinct return_date from book_transaction";
	String transId = "select BK_SEQ.currval from book_transaction";
	String chkStatus = "select return_date from book_transaction";
}
