package com.library.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.library.bean.LibraryBean;
import com.library.exception.LibraryException;
import com.library.service.ILibraryService;
import com.library.service.LibraryService;

public class LibraryUI {
	static boolean request;
	static String userName,emailId,password,bookId,bookName,author1,author2;
	static boolean requestBook,returnBook;
	static int userId;
	static Scanner scan = new Scanner(System.in);
	static ILibraryService service = null;
	static LibraryBean bean = new LibraryBean();
	static ArrayList<LibraryBean> bookList = new ArrayList<LibraryBean>();
	static BufferedReader br = null;
	public static void main(String[] args) throws IOException {
		service = new LibraryService();
		System.out.println("Username:");
		userName = scan.next();
		System.out.println("Password:");
		password = scan.next();
		
		boolean logres = false;
			try {
				logres = service.login(userName,password);
			} catch (LibraryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		if(logres)
		{
			
			System.out.println("Login successfull");
			
			
		
			while(true)
			{
			System.out.println("\n\n\n1 . View Books Available\n2 . Place Request for Book \n3 . Return Book \n4 . Exit");
				
			System.out.println("Enter Operation:");
			int choice = scan.nextInt();
			switch(choice)
			{
			case 1:
				try {
					bookList=service.view(bean);
				} catch (LibraryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Book-Name	Author1 	Author2		Publisher	Year of publication\n");
				for(LibraryBean bean:bookList)
				{
					System.out.println(bean);
				}break;
			case 2:
					System.out.println("Enter the book Name:");
					br = new BufferedReader(new InputStreamReader(System.in));
					String bkname = br.readLine().toLowerCase();
				
				try {
					request = service.placeRequest(bkname,bean);
				} catch (LibraryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					if(request)
					{
						System.out.println("Your Request is placed successfully");
						System.out.println("Expected return date is : "+bean.getReturnDate());
						System.out.println("Transaction Id:"+bean.getTransId());
					}
					else
					{
						System.out.println("No such book available");
					}
					;break;
			case 3:
				
				boolean returnStatus = false;
				System.out.println("Enter your transaction id:");
				int transId = scan.nextInt();
				
				try {
					boolean resturnBook = service.returnBook(transId,bean);
				} catch (LibraryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:System.out.println("You Exited From the system");System.exit(0);
			default:System.out.println("You entered invalid choice!!!"); 
			}
		}
		}
		else
		{
			System.out.println("Login unsuccessful");
		}
	
	}

}
