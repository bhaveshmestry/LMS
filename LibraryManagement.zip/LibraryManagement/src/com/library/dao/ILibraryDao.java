package com.library.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.library.bean.LibraryBean;
import com.library.exception.LibraryException;

public interface ILibraryDao {

	boolean login(String userName, String password) throws LibraryException;

	ArrayList<LibraryBean> view() throws  LibraryException;

	boolean placeRequest(String bookName) throws LibraryException;



}
