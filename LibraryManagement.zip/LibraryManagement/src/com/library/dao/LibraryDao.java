package com.library.dao;

import java.awt.print.Book;
import java.security.interfaces.RSAKey;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.library.bean.LibraryBean;
import com.library.dbutil.DBConnectivity;
import com.library.dbutil.IQueryMapper;
import com.library.exception.LibraryException;

public class LibraryDao implements ILibraryDao{
	static Connection conn = null;
	//static
	//static
	@Override
	public boolean login(String userName, String password) throws LibraryException {
		// TODO Auto-generated method stub
		boolean status = false; 
		try {
			conn = DBConnectivity.connect();
			PreparedStatement ps1;

			ps1 = conn.prepareStatement(IQueryMapper.login);

			ps1.setString(1, userName);
			ps1.setString(2, password);
			ResultSet result1 = ps1.executeQuery();
			if(result1.next())
			{
				status = true;

			}
			return status;}
		catch (SQLException e) {
			throw new LibraryException("Database Problem"+e.getMessage());
		}

	}
	@Override
	public ArrayList<LibraryBean> view() throws LibraryException {
		// TODO Auto-generated method stub
		LibraryBean bean = null;
		try{
			ArrayList<LibraryBean> booklist = new ArrayList<LibraryBean>();
			conn = DBConnectivity.connect();
			PreparedStatement ps2 = conn.prepareStatement(IQueryMapper.view);
			ResultSet result2 = ps2.executeQuery();
			while(result2.next())
			{
				bean=new LibraryBean();
				bean.setBookId(result2.getInt(1));
				bean.setBookName(result2.getString(2));
				bean.setAuthor1(result2.getString(3));
				bean.setAuthor2(result2.getString(4));
				bean.setPublisher(result2.getString(5));
				bean.setYearofpublication(result2.getString(6));
				booklist.add(bean);
			}

			return booklist;
		}
		catch (SQLException e) {
			throw new LibraryException("Database Problem"+e.getMessage());
		}
	}
	@Override
	public boolean placeRequest(String bookName) throws LibraryException {
		// TODO Auto-generated method stub
		LibraryBean bean = null;
		boolean availability=false;
		try{
			ArrayList<LibraryBean> booklist = new ArrayList<LibraryBean>();
			conn = DBConnectivity.connect();
			PreparedStatement ps3 = conn.prepareStatement(IQueryMapper.checkavail); 
			ResultSet result3 = ps3.executeQuery();
			while(result3.next())
			{
				bean=new LibraryBean();
				bean.setBookName(result3.getString("book_name"));
				if((result3.getString("book_name").toLowerCase().equals(bookName)))
				{
					availability = true;
				}
			}
			ps3 = conn.prepareStatement(IQueryMapper.insert); 
			int result4 = ps3.executeUpdate();
			ps3 = conn.prepareStatement(IQueryMapper.select); 
			ResultSet result5 = ps3.executeQuery();
			while(result5.next())
			{
				bean = new LibraryBean();

				bean.setReturnDate(result5.getString("return_date"));

				System.out.println("Expected return date is : "+result5.getString("return_date"));

			}

			return availability;

		}
		catch (SQLException e) {
			throw new LibraryException("Database Problem"+e.getMessage());
		}

	}
}
