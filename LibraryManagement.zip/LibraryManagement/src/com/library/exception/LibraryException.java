package com.library.exception;

public class LibraryException extends Exception {

	public LibraryException( String msg) {
		super ();
	}

}
