package com.library.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.library.bean.LibraryBean;
import com.library.exception.LibraryException;

public interface ILibraryService {

	boolean login(String userName, String password) throws  LibraryException;

	ArrayList<LibraryBean> view(LibraryBean bean) throws LibraryException;

	boolean placeRequest(String bookName) throws LibraryException;

	

}
