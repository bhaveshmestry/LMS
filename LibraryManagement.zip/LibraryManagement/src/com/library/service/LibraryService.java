package com.library.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.library.bean.LibraryBean;
import com.library.dao.ILibraryDao;
import com.library.dao.LibraryDao;
import com.library.exception.LibraryException;

public class LibraryService implements ILibraryService{
static ILibraryDao libdao = null;
	@Override
	public boolean login(String userName, String password) throws LibraryException {
		// TODO Auto-generated method stub
		libdao = new LibraryDao();
		
		/*boolean status = false;
		
		if(userName.equals("admin")&&password.equals("admin"))
		{
			status = true;
		}*/
		return libdao.login(userName,password);
	}

	@Override
	public ArrayList<LibraryBean> view(LibraryBean bean) throws LibraryException {
		// TODO Auto-generated method stub
		libdao = new LibraryDao();
		return libdao.view();
	}


	@Override
	public boolean placeRequest(String bookName) throws  LibraryException {
		// TODO Auto-generated method stub
		libdao = new LibraryDao();
		return libdao.placeRequest(bookName);
	}

}
