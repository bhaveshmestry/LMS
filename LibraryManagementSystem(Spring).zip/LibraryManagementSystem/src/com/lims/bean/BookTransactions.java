package com.lims.bean;

import javax.persistence.*;

@Entity
public class BookTransactions {
	
	@Id
	@GeneratedValue
	@Column(name="TRANSACTION_ID")
	private int transactionId;
	@Column(name="ISSUE_DATE")
	private int issueDate;
	@Column(name="RETURN_DATE")
	private int returnDate;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(int issueDate) {
		this.issueDate = issueDate;
	}
	public int getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(int returnDate) {
		this.returnDate = returnDate;
	}
	
	
	
}
