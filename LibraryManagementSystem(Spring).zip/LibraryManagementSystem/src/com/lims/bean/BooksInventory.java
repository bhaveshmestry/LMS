package com.lims.bean;

import javax.persistence.*;

@Entity
public class BooksInventory {
	
	@Id
	@GeneratedValue
	@Column(name="BOOK_ID")
	private int bookId;
	@Column(name="BOOK_NAME")
	private String bookName;
	@Column(name="AUTHOR1")
	private String author1;
	@Column(name="AUTHOR2")
	private String author2;
	@Column(name="PUBLISHER")
	private String publisher;
	@Column(name="YEAROFPUBLICATION")
	private String yearOfPublication;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor1() {
		return author1;
	}
	public void setAuthor1(String author1) {
		this.author1 = author1;
	}
	public String getAuthor2() {
		return author2;
	}
	public void setAuthor2(String author2) {
		this.author2 = author2;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getYearOfPublication() {
		return yearOfPublication;
	}
	public void setYearOfPublication(String yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}
	
	
	
}
