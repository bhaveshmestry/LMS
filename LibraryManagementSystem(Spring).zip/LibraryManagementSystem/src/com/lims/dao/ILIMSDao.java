package com.lims.dao;

public interface ILIMSDao {

}
