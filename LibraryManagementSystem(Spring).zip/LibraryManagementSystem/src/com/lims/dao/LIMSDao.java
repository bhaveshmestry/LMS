package com.lims.dao;

public class LIMSDao {

}
