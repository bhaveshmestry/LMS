package com.lims.service;

public interface ILIMSService {

}
