package com.lims.service;

public class LIMSService {

}
